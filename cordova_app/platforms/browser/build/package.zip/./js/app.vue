<template>
  <div class="app">      
    <h1>Test</h1>
    <p>{{test}}</p>
  </div>
</template>

<script>
export default {
  data () {
    return {
      test: 'Hello World!'
    }
  },
}
</script>